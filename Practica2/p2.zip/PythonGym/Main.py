from LGymClient import agentLoop
from BaseAgent import BaseAgent

agent = BaseAgent("1","Isma")

agentLoop(agent,True)
